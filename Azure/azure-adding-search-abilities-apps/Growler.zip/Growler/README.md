# Growler (Sample App)
This app serves as a test front-end for the growler search service.
It's used for educational purposes to learn about Azure Search.

## Setup
This is a plain HTML file that will need to be hosted on some web server to work.
If you're looking to get up and running with this quickly, I recommend the awesome [lite-server](https://github.com/johnpapa/lite-server).

## Note
If you're reading this, would you consider giving this course a shout-out on Twitter?
Or, perhaps showing your support by just liking the page available here:
[https://www.ecofic.com/courses/adding-search-abilities-to-your-apps-with-azure-search](https://www.ecofic.com/courses/adding-search-abilities-to-your-apps-with-azure-search)
